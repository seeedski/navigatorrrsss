# USTP Campus Navigator – v2 changes (originals kept in ../ustp-navigator and ../BACKUP_v1_before_transitions)

- Route line: ONE line only. Cause of the "two lines": the route was drawn twice (a ground layer lifted 9px, which
  shifted ~16px on screen in 3D and was thicker in 2D, plus the flat top layer). Now only the flat top layer draws it
  (visible in 2D and 3D, never hidden by buildings), with direction arrows.
- Directions: all walkway/shortcut pieces are merged into one clear step; "toward <destination>" is used only for the last step.
- Routes: shortcuts now join the two closest points of neighbouring buildings (when nothing blocks the way).
  Average route 213 m -> 181 m, long detours 20 -> 2 (the remaining ones are blocked by a real building).
- Map: removed the dotted walking lines; building names show when zoomed in (numbers only when zoomed out);
  red shop strips have no label; names slide below the A/B pins.
- Shapes: Bldg 6 and the two red commercial strips re-traced from the real OSA map pixels (the first versions were off).
- Cleanup: removed unused pin/marker code, the old ground route layer, and a broken building-info call.

## Device update
- Tested 18 screen sizes (280px foldable -> 4K, phones in portrait and landscape, tablets): no overlaps, no sideways scrolling.
- Small phones: compact planner so "Get Directions" is visible without scrolling. Short landscape phones: the button stays pinned.
- Touch: two-finger pinch to zoom (one finger still drags). Mouse wheel / trackpad pinch / Shift+drag rotate unchanged.
- Big screens (>=1800px, >=2500px): the panel and map buttons scale up.
- Rotating the phone with a route shown keeps everything usable; Enter key in the destination box starts directions.
- Added home-screen web-app tags for iOS/Android. Needs a browser from about 2021 or newer (iOS 14.5+, Android Chrome 90+).
